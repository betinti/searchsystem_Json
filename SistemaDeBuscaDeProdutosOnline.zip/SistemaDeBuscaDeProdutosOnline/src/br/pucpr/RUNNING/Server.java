package br.pucpr.RUNNING;

import br.pucpr.Servidor.Servidor;

public class Server {

    public static void main(String[] args) throws Exception {

        new Servidor().COMUNICACAO();

    }

}
