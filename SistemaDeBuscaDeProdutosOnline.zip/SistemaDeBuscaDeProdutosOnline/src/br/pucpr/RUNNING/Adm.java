package br.pucpr.RUNNING;

import br.pucpr.Administrador.Administrador;

public class Adm {

    public static void main(String[] args) throws Exception{

        new Administrador().comunicacaoServidor();

    }

}
