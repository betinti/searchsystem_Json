package br.pucpr.RUNNING;

import br.pucpr.Cliente.Consumidor;

public class Cliente_02 {

    public static void main(String[] args) throws Exception{

        new Consumidor().comunicacaoServidor();

    }

}
