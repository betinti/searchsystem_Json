package br.pucpr.RUNNING;

import br.pucpr.Loja.Loja;

public class Store {

    public static void main(String[] args) throws Exception{

        new Loja("Pão de Açucar").COMUNICACAO();

    }

}
