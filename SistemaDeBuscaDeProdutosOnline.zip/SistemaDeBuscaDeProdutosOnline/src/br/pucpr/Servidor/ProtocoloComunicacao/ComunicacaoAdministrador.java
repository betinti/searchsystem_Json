package br.pucpr.Servidor.ProtocoloComunicacao;

import br.pucpr.Auxiliares.*;
import br.pucpr.Servidor.Servidor;

import java.io.*;
import java.net.*;

public class ComunicacaoAdministrador extends Thread{

    //TODO: Comunicacao - TCP
    private final ServerSocket server;
    private Socket administrador;
    private PrintWriter sendData;

    private String data;


    public ComunicacaoAdministrador (ServerSocket serverSocket){
        this.server = serverSocket;
    }

    @Override
    public void run() {
        while (true)
            try {

                printarAdministrador(admCommunication());

            } catch (NullPointerException nullPointerException){
                printarAdministrador(Legendar.Sistema + "ERROR >> comunicação interrompida ...");
            } catch (Exception e){
                e.printStackTrace();
            }
    }

    //TODO: protocolo para o Adm vizualizar e modificar o Tmax
    private String admCommunication() throws Exception {
        System.out.print(Legendar.Servidor);
        administrador = server.accept();
        sendData = new PrintWriter(administrador.getOutputStream());

        printarAdministrador("Nova solicitação do Administrador");

        data = Comunicacao.receber(administrador).toLowerCase();


        switch (data) {
            case "historico":
                return HISTORICO();
            case "carregar":
                return CARREGAR(Comunicacao.receber(administrador));
            case "salvar":
                return SALVAR();
            case "sair":
                return "Administrador encerrou a sessão";
            default:
                return ERROR();
        }
    }


    private String HISTORICO() throws Exception{
        Comunicacao.enviar(administrador, JsonConverter.ToJson(Servidor.acessoMem()));
        String win = "Historico enviado com sucesso";
        return win;
    }

    private String SALVAR() throws Exception{
        Servidor.historico.armazenar();
        String success = "Historico salvo com sucesso!";
        Comunicacao.enviar(administrador, success);
        return success;
    }

    private String CARREGAR(String path) throws Exception{
        Servidor.historico.carregar(path);
        String success = "Historico carregado com sucesso!";
        Comunicacao.enviar(administrador, success);
        return success;
    }

    private String ERROR() throws Exception{
        Comunicacao.enviar(administrador, "ERROR -> Comando inválido");
        return "ERROR -> Comando inválido";
    }


    private void printarAdministrador(String info){
        System.out.print(Legendar.Adiministrador + "Administrador: ");
        System.out.print(Legendar.Servidor + info);
        System.out.println();
    }
}
