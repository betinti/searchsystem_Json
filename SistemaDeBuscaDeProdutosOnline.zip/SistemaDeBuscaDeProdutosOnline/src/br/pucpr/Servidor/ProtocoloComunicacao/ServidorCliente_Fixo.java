package br.pucpr.Servidor.ProtocoloComunicacao;

import br.pucpr.Auxiliares.*;

import java.net.*;

public class ServidorCliente_Fixo extends Thread{

    private final ServerSocket server;
    private Socket consumidor;

    private int autoPortas;

    public ServidorCliente_Fixo(ServerSocket serverSocket) {
        this.server = serverSocket;

        this.autoPortas = 5888;
    }

    @Override
    public void run() {
        while (true)
            try {

                controladorConsumidor();

            } catch (Exception e){
                e.printStackTrace();
            }
    }


    private void controladorConsumidor() throws Exception {
        consumidor = server.accept();

        Comunicacao.enviar(consumidor, String.valueOf(autoPortas));

        printarConsumidor("Nova porta enviada: " + autoPortas);

        new ServidorCliente_Variavel(autoPortas).start();

        printarConsumidor("Novo cliente na área");

        ++autoPortas;
    }

    private void printarConsumidor(String info){
        System.out.print(Legendar.Consumidor + "Consumidor: ");
        System.out.print(Legendar.Servidor + info);
        System.out.println();
    }
}
