package br.pucpr.Servidor.ProtocoloComunicacao;

import br.pucpr.Auxiliares.*;
import br.pucpr.Loja.ProtocoloComunicacao.MsgProdutos;
import br.pucpr.Servidor.Servidor;

import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.Semaphore;

public class ServidorCliente_Variavel extends Thread{

    protected static final ArrayList<String> recebidos = new ArrayList<>();
    private static final Semaphore mutexRecebidos = new Semaphore(1);

    protected static final Semaphore sync = new Semaphore(1);

    private final int id;

    private boolean working;

    //TODO: Saves - loja
//    protected static final ArrayList<String> infos = new ArrayList<>();
//    private static final Semaphore mutexSaves = new Semaphore(1);

    //TODO: Comunicação - TCP
    //Cliente
    private final ServerSocket server;
    private Socket consumidor;
    private PrintWriter sendData;



    public ServidorCliente_Variavel(int id) throws Exception {
        this.id = id;
        working = true;
        //TCP
        this.server = new ServerSocket(id);
    }


    @Override
    public void run() {
        while (working)
            try {

                consComunicacao();


            } catch (Exception e){
                e.printStackTrace();
//                printarConsumidor(Legendar.msgErrorStr("Comando inválido"));
            }
    }

    private void consComunicacao() throws Exception {
        System.out.print(Legendar.Servidor);
        consumidor = server.accept();
        sendData = new PrintWriter(consumidor.getOutputStream());

        printarConsumidor("Nova solicitação do cliente");

        String recived_Cliente = Comunicacao.receber(consumidor);   //receber do cliente


        printarConsumidor(id + " informação recebida -> " + recived_Cliente);


        if (recived_Cliente == null)
        {
            printarConsumidor(Legendar.msgErrorStr("Comando inválido"));
            return;
        }


        if (check(recived_Cliente))
        {
            Servidor.mutexComunicacao_ServidorCliente.acquire();

            new ServidorLoja(recived_Cliente).comunicacao();      //comunicacao com a loja



            saveSearch(recived_Cliente, JsonConverter.JSontoMsgProdutos(getUltimoRecebido()));


            Comunicacao.enviar(consumidor, getUltimoRecebido());

            printarConsumidor("ser.cli._var: enviado");

            Servidor.mutexComunicacao_ServidorCliente.release();

            System.out.println("ser.cli._var: passou do semáforo");
        }
        else if (recived_Cliente.equals("sair"))
        {
            printarConsumidor(id + " encerrou a sessão");
            working = false;
        }
        else
            ERROR(recived_Cliente);
    }

    private void ERROR(String data) throws Exception{
        String msg = "ERROR -> Comando '" + data + "' inválido";
        Comunicacao.enviar(consumidor, msg);
        printarConsumidor(msg);
    }


    //staticas

    protected static void accessRecebidos(String info) throws Exception {
        mutexRecebidos.acquire();
        recebidos.add(info);
        mutexRecebidos.release();
    }

    private String saveSearch(String textoParcial, MsgProdutos msgProdutos) throws Exception {
        Servidor.acessoMem(String.valueOf(id), textoParcial, msgProdutos);
        return msgProdutos.getNomeCategoria();
    }


    //auxiliares

    private String getUltimoRecebido(){
        return recebidos.get(recebidos.size()-1);
    }

    private void printarConsumidor(String info){
        System.out.print(Legendar.Consumidor + "Consumidor [" + id + "]: ");
        System.out.print(Legendar.Servidor + info);
        System.out.println();
    }

    private boolean check (String input){
        String[] aux = {"1", "2", "3", "4", "5"};
        for (String s : aux)
            if (s.equals(input))
                return true;
        return false;
    }

}
