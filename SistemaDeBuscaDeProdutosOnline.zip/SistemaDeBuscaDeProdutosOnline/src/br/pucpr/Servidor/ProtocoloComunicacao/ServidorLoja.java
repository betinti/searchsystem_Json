package br.pucpr.Servidor.ProtocoloComunicacao;

import br.pucpr.Auxiliares.*;
import br.pucpr.Loja.Loja;

import java.net.Socket;
import java.util.Objects;

public class ServidorLoja extends Thread{


    //Comunicacao
    private Socket socketFixo;
    private Socket socketVariavel;
    private int novaPorta;

    private final String info;

    public ServidorLoja(String info) throws Exception {
        this.info = info;
        BEGIN_CONNECTION();
    }

    @Override
    public void run() {
        try {

            comunicacao();

            System.out.println("Comunicação com a loja  finalizada");

        } catch (Exception e){
            e.printStackTrace();
        }
    }


    protected void comunicacao() throws Exception {

        ServidorCliente_Variavel.sync.acquire();

        this.socketVariavel = new Socket("localhost", novaPorta);

        System.out.println("comunicação iniciada");

        Comunicacao.enviar(socketVariavel, info);

        System.out.println("info enviada");

        ServidorCliente_Variavel.accessRecebidos(Comunicacao.receber(socketVariavel));

        System.out.println("info recebida com sucesso");

        ServidorCliente_Variavel.sync.release();
    }


    private void BEGIN_CONNECTION() throws Exception {
        try
        {
            this.socketFixo = new Socket("localhost", Loja.portaLojaFixo);
            System.out.println("Conexão com a loja estabelecida");
            novaPorta = Integer.parseInt(Objects.requireNonNull(Comunicacao.receber(socketFixo)));
            System.out.println("Nova porta recebida da loja: " + novaPorta);
            socketFixo.close();
            System.out.println("Nova conexão criada");
        }
        catch (Exception e)
        {
            Legendar.msgError("falha na conexão com o serevidor");
        }
    }

}
