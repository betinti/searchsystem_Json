package br.pucpr.Servidor;

import br.pucpr.Auxiliares.Legendar;
import br.pucpr.Loja.ProtocoloComunicacao.MsgProdutos;
import br.pucpr.ProtocoloSave.Memoria_InfoSaves;
import br.pucpr.Servidor.ProtocoloComunicacao.*;

import java.net.ServerSocket;
import java.util.concurrent.Semaphore;

public class Servidor {

    //TODO: Statics

    //chave de criptografia
    public static final int key = 10;

    //Portas de cada comunicação TCP
    public static final int portaAdm = 5788;
    public static final int portaCon = 5688;

    //Protocolo para salvar os dados
    public static final Memoria_InfoSaves historico = new Memoria_InfoSaves();
    public static final Semaphore mutexMem = new Semaphore(1);



    //Todo: Comunicação
    private final ServerSocket server_Adm;
    private final ServerSocket server_Cons;
    public static final Semaphore mutexComunicacao_ServidorCliente = new Semaphore(1);
    public static final Semaphore mutexComunicacao_ServidorLoja = new Semaphore(1);




    public Servidor() throws Exception {
        this.server_Adm = new ServerSocket(portaAdm);       //Server
        this.server_Cons = new ServerSocket(portaCon);       //Server

        System.out.println(Legendar.Servidor + "servidor: ON");
    }



    //TODO: 'Protegidas'

    public static Memoria_InfoSaves acessoMem() throws Exception {
        mutexMem.acquire();
//        MemoriaServer aux = memoriaServidor;
            Memoria_InfoSaves aux = historico;
        mutexMem.release();
        return aux;
    }

    public static void acessoMem(String id, String textoParcial, MsgProdutos msgProdutos) throws Exception {
        mutexMem.acquire();
            historico.addSave(id, textoParcial, msgProdutos);
        mutexMem.release();
    }


    //TODO: Comunicação

    public void COMUNICACAO() throws Exception {

        new ComunicacaoAdministrador(server_Adm).start();

        new ServidorCliente_Fixo(server_Cons).start();

        System.out.println(Legendar.Servidor + "SERVIDOR ON");
    }

}
