package br.pucpr.Cliente;

import br.pucpr.Auxiliares.*;
import br.pucpr.Loja.Produtos.Catalogo;
import br.pucpr.Loja.ProtocoloComunicacao.MsgProdutos;
import br.pucpr.Servidor.Servidor;

import java.net.*;
import java.util.*;

public class Consumidor {

    private final Scanner input;

    private String data;

    private String arrived;

    //TODO: Comunicação - TCP
    private Socket socketFixo;
    private Socket socketVariavel;
    private int novaPorta;

    public Consumidor() throws Exception{
        input = new Scanner(System.in);


        BEGIN_CONNECTION();
    }


    public void comunicacaoServidor() throws Exception {

        System.out.print(Legendar.Consumidor);

        this.socketVariavel = new Socket("localhost", novaPorta);

        MENU(); //Interface Humano Computador

        data = input.nextLine();


        if (check(data))
        {
            Comunicacao.enviar(socketVariavel, data);



            RECEBER();

            IMPRIMIR_CATALOGOS();

            AGAIN();
        }
        else if (data.equals("sair"))
        {
            Comunicacao.enviar(socketVariavel, data);
            SAIR();
        }
        else
        {
            System.out.println("Error >> comando '" + data + "' invalido ... tente novamente");
            AGAIN();
        }
    }





    private void BEGIN_CONNECTION() throws Exception{
        try
        {
            this.socketFixo = new Socket("localhost", Servidor.portaCon);
//            System.out.println("conexão com o servidor estabelecida");
            novaPorta = Integer.parseInt(Objects.requireNonNull(Comunicacao.receber(socketFixo)));
//            System.out.println("Nova porta recebida: " + novaPorta);
            socketFixo.close();
//            System.out.println("nova conexão criada");
        }
        catch (Exception e)
        {
            Legendar.msgError("falha na conexão com o serevidor");
        }
    }

    private void MENU(){
        System.out.print(Legendar.Consumidor);
        System.out.println(".-------------------------------------------.");
        System.out.println("|            Bem Vindo(a) ao SBPO           |");
        System.out.println("|    Sistema de Busca de Produtos Online    |");
        System.out.println("|===========================================|");
        System.out.println("|                Consumidor                 |");
        System.out.println("|===========================================|");
        System.out.println("|   Digite o código da categoria do produto |");
        System.out.println("|   procurado e deixe eu te mostrar o que   |");
        System.out.println("|   eu encontro em minhas lojas cadastradas |");
        System.out.println("|===========================================|");
        System.out.println("|       - 1 -> comidas                      |");
        System.out.println("|       - 2 -> bebidas                      |");
        System.out.println("|       - 3 -> produtos de limpeza          |");
        System.out.println("|       - 4 -> roupas                       |");
        System.out.println("|       - 5 -> eletronicos                  |");
        System.out.println("|===========================================|");
        System.out.println("|   Se deseja encerrar a sessão, digite     |");
        System.out.println("|   'sair'.                                 |");
        System.out.println("°-------------------------------------------°" + "\n");
        System.out.print("->> Comando: ");
    }

    private void RECEBER() throws Exception{
        System.out.println("    Informação enviada -> " + Catalogo.conver(data));

        arrived = Comunicacao.receber(socketVariavel);

        System.out.println("    Informações recebidas: ");
        System.out.println();
    }

    private void IMPRIMIR_CATALOGOS(){
//        System.out.println("produtos recebidos com sucesso!");
//        System.out.println("sistema ainda em manuetenção kk");

        MsgProdutos msgProdutos = JsonConverter.JSontoMsgProdutos(arrived);

        msgProdutos.getCategoria().imprimirProdutos();

        System.out.println();
    }

    private void AGAIN() throws Exception {
        System.out.println();
        socketVariavel.close();
        comunicacaoServidor();
    }

    private void SAIR() throws Exception{
        System.out.println();
        System.out.println(".-------------------------------------------.");
        System.out.println("|    Sistema de Busca de Produtos Online    |");
        System.out.println("|===========================================|");
        System.out.println("|                Consumidor                 |");
        System.out.println("|===========================================|");
        System.out.println("|   Muito obrigado pela visita!             |");
        System.out.println("|   Até outra hora.                         |");
        System.out.println("°-------------------------------------------°" + "\n");

        socketVariavel.close();
    }



    private boolean check (String input){
        String[] aux = {"1", "2", "3", "4", "5"};
        for (String s : aux)
            if (s.equals(input))
                return true;
        return false;
    }


}
