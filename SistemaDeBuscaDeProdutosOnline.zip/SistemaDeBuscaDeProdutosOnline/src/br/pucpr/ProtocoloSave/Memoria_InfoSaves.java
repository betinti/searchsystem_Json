package br.pucpr.ProtocoloSave;

import br.pucpr.Auxiliares.JsonConverter;
import br.pucpr.Auxiliares.Legendar;
import br.pucpr.Loja.Produtos.Catalogo;
import br.pucpr.Loja.ProtocoloComunicacao.MsgProdutos;

import java.io.*;
import java.util.*;

public class Memoria_InfoSaves {

    private ArrayList<InfoSave> saves;

    private String pathSaves;

    public Memoria_InfoSaves(){
        saves = new ArrayList<>();
        pathSaves = "historico.txt";
    }


    public void addSave(String identificador, String textoParcial, MsgProdutos msgProdutos){
        saves.add(new InfoSave(new Date(), identificador, textoParcial, msgProdutos));
    }

    public void armazenar() throws Exception{
        BufferedWriter bw = new BufferedWriter(new FileWriter(new File("historico.txt")));
        bw.append(String.valueOf(saves.size()));
        bw.newLine();
        for (InfoSave infoSave : saves){
            bw.append(JsonConverter.ToJson(infoSave)).flush();
            bw.newLine();
        }
        bw.close();
    }

    public void carregar(String path) throws Exception {
        try {
            BufferedReader br = new BufferedReader(new FileReader(new File(path)));
            int size = Integer.parseInt(br.readLine());
            for (int i = 0; i < size; i++)
                saves.add(JsonConverter.JSontoInfoSave(br.readLine()));
        } catch (NumberFormatException numberFormatException){
            System.out.println(Legendar.Sistema + "ERROR >> conrrompido ... ");
        } catch (FileNotFoundException fileNotFoundException){
            System.out.println(Legendar.Sistema + "ERROR >> arquivo não encontrado ...");
        }
    }

    public ArrayList<InfoSave> getSaves(){
        return saves;
    }


    public void imprimirSaves(){
        if (saves.size() == 0){
            System.out.println("Nenhum dado salvo até o momento");
            return;
        }

        String[] titulos = {"Data Recibido", "Identificador", "Palavra Chave", "Data Busca"};
        int[] espacoTotal = new int[titulos.length];
        Arrays.fill(espacoTotal, 0);

        for (InfoSave infoSave : saves){
            if (String.valueOf(infoSave.getDate()).length() > espacoTotal[0])
                espacoTotal[0] = String.valueOf(infoSave.getDate()).length();
            if (infoSave.getNomeCliente().length() > espacoTotal[1])
                espacoTotal[1] = infoSave.getNomeCliente().length();
            if (infoSave.getNomeCliente().length() > espacoTotal[2])
                espacoTotal[2] = infoSave.getNomeCliente().length();
            if (String.valueOf(infoSave.getMsgProdutos().getDate()).length() > espacoTotal[3])
                espacoTotal[3] = String.valueOf(infoSave.getMsgProdutos().getDate()).length();
        }

        //cabeçalho
        for (int i = 0; i < titulos.length; i++)
            System.out.print(getFormated(espacoTotal[i], titulos[i], titulos[i]));
        System.out.println();

        for (int i = 0; i < saves.size(); i++){
            System.out.print(getFormated(espacoTotal[0], String.valueOf(saves.get(i).getDate()), titulos[0]));
            System.out.print(getFormated(espacoTotal[1], String.valueOf(saves.get(i).getNomeCliente()), titulos[1]));
            System.out.print(getFormated(espacoTotal[2], Catalogo.conver(saves.get(i).getTextoParcial()), titulos[2]));
            System.out.print(getFormated(espacoTotal[3], String.valueOf(saves.get(i).getMsgProdutos().getDate()), titulos[3]));
            System.out.println();
        }
    }

    private String getFormated(int tamTotal, String word, String titulo){
        StringBuilder stringBuilder = new StringBuilder();
        int size = tamTotal - word.length() + titulo.length();
        stringBuilder.append(word);
        for (int i = 0; i < size; i++)
            stringBuilder.append(" ");
        stringBuilder.append("  ");
        return new String(stringBuilder);
    }

}
