package br.pucpr.ProtocoloSave;

import br.pucpr.Loja.ProtocoloComunicacao.MsgProdutos;

import java.util.Date;

public class InfoSave {

    private final Date date;
    private final String nomeCliente;
    private final String textoParcial;
    private final MsgProdutos msgProdutos;

    public InfoSave (Date date, String identificador, String textoParcial, MsgProdutos msgProdutos){
        this.date = date;
        this.nomeCliente = identificador;
        this.textoParcial = textoParcial;
        this.msgProdutos = msgProdutos;
    }

    public Date getDate() {
        return date;
    }

    public String getTextoParcial() {
        return textoParcial;
    }

    public MsgProdutos getMsgProdutos() {
        return msgProdutos;
    }

    public String getNomeCliente() {
        return nomeCliente;
    }
}
