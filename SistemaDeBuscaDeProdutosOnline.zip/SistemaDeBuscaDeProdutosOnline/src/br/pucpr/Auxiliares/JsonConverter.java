package br.pucpr.Auxiliares;


import br.pucpr.Loja.ProtocoloComunicacao.MsgProdutos;
import br.pucpr.ProtocoloSave.InfoSave;
import br.pucpr.ProtocoloSave.Memoria_InfoSaves;
import com.google.gson.Gson;


public class JsonConverter {

    public static String ToJson(InfoSave infoSave){
        return new Gson().toJson(infoSave);
    }

    public static String ToJson(MsgProdutos msgProdutos){
        return new Gson().toJson(msgProdutos);
    }

    public static String ToJson(Memoria_InfoSaves memoria_infoSaves){
        return new Gson().toJson(memoria_infoSaves);
    }

    public static InfoSave JSontoInfoSave(String json){
        return new Gson().fromJson(json, InfoSave.class);
    }

    public static MsgProdutos JSontoMsgProdutos(String json){
        return new Gson().fromJson(json, MsgProdutos.class);
    }

    public static Memoria_InfoSaves JSontoMemoriaSavez(String json){
        return new Gson().fromJson(json, Memoria_InfoSaves.class);
    }

}
