package br.pucpr.Auxiliares;

import java.io.*;
import java.net.*;

public class Comunicacao {

    public static String enviar(Socket socket, String data) throws Exception{
        String crip = Criptografia.criptografa(data, Criptografia.key);
        PrintWriter sendData = new PrintWriter(socket.getOutputStream());
        sendData.println(crip);
        sendData.flush();
        return crip;
    }

    public static String receber(Socket socket) throws Exception{
        try {
            return Criptografia.descriptografa(new BufferedReader(new InputStreamReader(socket.getInputStream())).readLine(), Criptografia.key);
        } catch (SocketException socketException){
            System.out.println(Legendar.Sistema + "ERROR >> comunicação interrompida ...");
            return null;
        }
    }
}
