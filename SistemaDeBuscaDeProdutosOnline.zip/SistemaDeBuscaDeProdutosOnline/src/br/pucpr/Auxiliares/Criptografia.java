package br.pucpr.Auxiliares;

public class Criptografia {

    public static final int key = 10;

    public static String criptografa(String texto, int key){
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < texto.length(); i++)
            sb.append((char) (texto.charAt(i)+key));
        return new String(sb);
    }

    public static String descriptografa(String texto, int key){
        try {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < texto.length(); i++)
                sb.append((char) (texto.charAt(i)-key));
            return new String(sb);
        } catch (NullPointerException nullPointerException){
            return "";
        }
    }


}
