package br.pucpr.Auxiliares;

public interface Legenda {

    //    https://stackoverflow.com/questions/5762491/how-to-print-color-in-console-using-system-out-println

    static String legendar(String cor, boolean negrito, boolean sublinhado) {
        return null;
    }

}
