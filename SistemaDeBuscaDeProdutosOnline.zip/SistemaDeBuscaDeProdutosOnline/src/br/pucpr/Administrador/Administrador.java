package br.pucpr.Administrador;

import br.pucpr.Auxiliares.*;
import br.pucpr.Servidor.Servidor;

import java.io.*;
import java.net.*;
import java.util.*;

public class Administrador {

    private final Scanner input;

    private String data, newTmax;

    //TODO: Comunicação - TCP
    private Socket socket;

    public Administrador(){
        input = new Scanner(System.in);
    }




    public void comunicacaoServidor() throws Exception {
        this.socket = new Socket("localhost", Servidor.portaAdm);

        MENU(); //Interface Humano Computador

        data = input.nextLine();
        System.out.println();
        Comunicacao.enviar(socket, data);

        //Recebimento
        switch (data) {
            case "historico":
                HISTORICO();
                AGAIN();
                break;
            case "salvar":
                SALVAR();
                AGAIN();
                break;
            case "carregar":
                CARREGAR();
                AGAIN();
                break;
            case "sair":
                SAIR();
                break;
            default:
                System.out.println("Comando inválido, tente novamente.");
                AGAIN();
                break;
        }

    }



    private void MENU() {
        System.out.print(Legendar.Adiministrador);
        System.out.println(".-------------------------------------------.");
        System.out.println("|            Bem Vindo(a) ao SBPO           |");
        System.out.println("|    Sistema de Busca de Produtos Online    |");
        System.out.println("|===========================================|");
        System.out.println("|               Administrador              |");
        System.out.println("|===========================================|");
        System.out.println("|   Você tem acesso aos controles do Tempo  |");
        System.out.println("|   Máximo de Envio das mensagens.          |");
        System.out.println("|   Digite 'historico' para ver os dados.   |");
        System.out.println("|   Digite 'salvar' para salvar os dados.   |");
        System.out.println("|   Digite 'carregar' para inserir saves.   |");
        System.out.println("|===========================================|");
        System.out.println("|   Se deseja encerrar a sessão, digite     |");
        System.out.println("|   'sair'.                                 |");
        System.out.println("°-------------------------------------------°" + "\n");
        System.out.print("->> Comando: ");
    }

    private void HISTORICO() throws Exception {
        JsonConverter.JSontoMemoriaSavez(Comunicacao.receber(socket)).imprimirSaves();
    }

    private void SALVAR() throws Exception {
        String success = Comunicacao.receber(socket);
        System.out.println(success);
    }

    private void CARREGAR() throws Exception {
        System.out.print("->> path Arquivo: ");
        String pathSaves = input.nextLine();
        try {
            new BufferedReader(new FileReader(new File(pathSaves))).close();
            Comunicacao.enviar(socket, pathSaves);

            String success = Comunicacao.receber(socket);
            System.out.println(success);

        } catch (FileNotFoundException e){
            System.out.println("O arquivo inserido não foi encontrado ...");
        }
    }

    private void SAIR() throws Exception{
        System.out.println(".-------------------------------------------.");
        System.out.println("|    Sistema de Busca de Produtos Online    |");
        System.out.println("|===========================================|");
        System.out.println("|               Adiministrador              |");
        System.out.println("|===========================================|");
        System.out.println("|   Muito obrigado pela visita!             |");
        System.out.println("|   Até outra hora.                         |");
        System.out.println("°-------------------------------------------°" + "\n");

        socket.close();
    }

    private void AGAIN() throws Exception {
        System.out.println();
        socket.close();
        comunicacaoServidor();
    }
}
