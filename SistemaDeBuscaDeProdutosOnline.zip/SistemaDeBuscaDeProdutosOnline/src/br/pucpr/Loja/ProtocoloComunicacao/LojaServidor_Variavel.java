package br.pucpr.Loja.ProtocoloComunicacao;

import br.pucpr.Auxiliares.*;
import br.pucpr.Loja.Loja;
import br.pucpr.Loja.Produtos.Catalogo;
import br.pucpr.Servidor.Servidor;

import java.net.*;

public class LojaServidor_Variavel extends Thread{

    private final int id;

    private String data;

    private boolean working;

    //TODO: Comunicação - TCP
    //Cliente
    private final ServerSocket server;
    private Socket consumidor;


    public LojaServidor_Variavel(int id) throws Exception {
        this.id = id;
        this.server = new ServerSocket(id);
        working = true;
    }


    @Override
    public void run() {
        while (working)
            try {

                consComunicacao();

            } catch (Exception e){
                e.printStackTrace();
            }
    }


    private void consComunicacao() throws Exception {
        System.out.print(Legendar.Servidor);
        consumidor = server.accept();

        printarConsumidor("Nova solicitação do cliente: " + id);

        data = Comunicacao.receber(consumidor);

        printarConsumidor(id + " informação recebida -> " + data);

        if (check(data))
        {
            Servidor.mutexComunicacao_ServidorLoja.acquire();

            String Json = JsonConverter.ToJson(new MsgProdutos(String.valueOf(id), Loja.accessProdutos().getCategoria(Catalogo.conver(data))));

            Comunicacao.enviar(consumidor, Json);
//            Comunicacao.enviar(consumidor, Json);

            printarConsumidor("enviado");

            Servidor.mutexComunicacao_ServidorLoja.release();
        }
        else if (data.equals("sair"))
        {
            printarConsumidor(id + " encerrou a sessão");
            working = false;
        }
        else
            ERROR();
    }

    private void ERROR() throws Exception{
        String msg = "ERROR -> Comando '" + data + "' inválido";
//        Comunicacao.enviar(consumidor, msg);
        Comunicacao.enviar(consumidor, msg);
        printarConsumidor(msg);
    }

    //auxiliares

    private void printarConsumidor(String info){
        System.out.print(Legendar.Consumidor + "Consumidor: ");
        System.out.print(Legendar.Servidor + info);
        System.out.println();
    }

    private boolean check (String input){
        String[] aux = {"1", "2", "3", "4", "5"};
        for (String s : aux)
            if (s.equals(input))
                return true;
        return false;
    }
}
