package br.pucpr.Loja.ProtocoloComunicacao;

import br.pucpr.Auxiliares.Comunicacao;
import br.pucpr.Auxiliares.Criptografia;
import br.pucpr.Auxiliares.Legendar;
import br.pucpr.Servidor.Servidor;

import java.net.*;

public class LojaServidor_Fixo extends Thread{

    private final ServerSocket loja;
    private Socket servidor;

    private int autoPortas;

    public LojaServidor_Fixo(ServerSocket serverSocket){
        this.loja = serverSocket;

        this.autoPortas = 8888;
    }


    @Override
    public void run() {
        while (true)
            try {

                controladorServidor();

            } catch (Exception e){
                e.printStackTrace();
            }
    }

    private void controladorServidor() throws Exception {
        servidor = loja.accept();

        printarServidor("Nova porta enviada: " + autoPortas);

        Comunicacao.enviar(servidor, String.valueOf(autoPortas));

        printarServidor("Novo cliente na área >> " + autoPortas);

        new LojaServidor_Variavel(autoPortas).start();

        ++autoPortas;
    }

    private void printarServidor(String info){
        System.out.print(Legendar.Servidor + "Consumidor: ");
        System.out.print(Legendar.Loja + info);
        System.out.println();
    }

}
