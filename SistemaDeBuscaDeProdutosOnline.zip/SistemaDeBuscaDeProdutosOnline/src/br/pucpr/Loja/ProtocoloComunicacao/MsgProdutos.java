package br.pucpr.Loja.ProtocoloComunicacao;

import br.pucpr.Loja.Produtos.Categoria;

import java.util.Date;

public class MsgProdutos {

    private final Date date;
    private final Categoria categoria;
    private final int nProdutos;
    private final String nomeLoja;

    public MsgProdutos (String nomeLoja, Categoria categoria){
        this.nomeLoja = nomeLoja;
        this.categoria = categoria;

        this.nProdutos = categoria.getnProdutos();

        this.date = new Date();
    }

    public Date getDate() {
        return date;
    }

    public String getNomeCategoria(){
        return categoria.getNome();
    }

    public Categoria getCategoria() {
        return categoria;
    }
}
