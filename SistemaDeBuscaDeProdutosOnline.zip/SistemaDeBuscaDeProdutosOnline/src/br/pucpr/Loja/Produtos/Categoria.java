package br.pucpr.Loja.Produtos;

import java.util.*;

public class Categoria {

    private final Random rnd = new Random();

    private final String nome;
    private final ArrayList<Produto> produtos;
    private final int nProdutos;



    public Categoria (String nome, int nMaxProdutos){
        this.nome = nome;
        this.nProdutos = rnd.nextInt(nMaxProdutos-1)+2;
        this.produtos = new ArrayList<>();
    }



    public int getnProdutos() {
        return nProdutos;
    }

    public Produto[] getProdutos() {
        Produto[] aux = new Produto[nProdutos];
        for (int i = 0; i < nProdutos; i++)
            aux[i] = produtos.get(i);
        return aux;
    }

    public String getNome() {
        return nome;
    }

    public void addProduto(String titulo, double preco){
        produtos.add(new Produto(titulo, preco));
    }

    public void imprimirProdutos(){
        String titulo01 = "Nome";
        String titulo02 = "   Valor";
        String espac = getMaiorEspacamento();
        //cabeçalho
        System.out.println(titulo01 + espac + titulo02);
        //Produtos
        for (Produto p : produtos)
            System.out.println(p.getTitulo() + getEspacos(espac.length()-p.getTitulo().length()+titulo01.length()) + "R$" + p.getPreco());
    }




    private String getMaiorEspacamento(){
        int bigger = produtos.get(0).getTitulo().length();
        for (Produto p : produtos)
            if (p.getTitulo().length() > bigger)
                bigger = p.getTitulo().length();
        return getEspacos(bigger);
    }

    private String getEspacos(int tam){
        StringBuilder stringBuilder = new StringBuilder();
        for (int i = 0; i < tam; i++)
            stringBuilder.append(" ");
        return new String(stringBuilder.append("   "));
    }
}
