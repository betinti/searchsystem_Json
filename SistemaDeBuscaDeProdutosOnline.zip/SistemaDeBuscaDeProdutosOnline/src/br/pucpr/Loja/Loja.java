package br.pucpr.Loja;

import br.pucpr.Auxiliares.Legendar;
import br.pucpr.Loja.Produtos.Catalogo;
import br.pucpr.Loja.ProtocoloComunicacao.LojaServidor_Fixo;

import java.net.ServerSocket;
import java.util.concurrent.Semaphore;

public class Loja {

    //TODO: Statics

    //Porta para loja fixa
    public static final int portaLojaFixo = 7788;

    //Catalogo
    private static Catalogo produtos = new Catalogo();
    private static Semaphore mutexCatalogo = new Semaphore(1);



    //TODO: Comunicação
    private final ServerSocket serverLoja;

    //TODO: Identificação
    private final String nome;



    public Loja(String nome) throws Exception {
        this.nome = nome;
        this.serverLoja = new ServerSocket(portaLojaFixo);

        System.out.println(Legendar.Loja + "Loja ON");
    }


    //TODO: 'Protegidas'

    public static Catalogo accessProdutos() throws Exception{
        mutexCatalogo.acquire();
        Catalogo aux = produtos;
        mutexCatalogo.release();
        return aux;
    }



    public void COMUNICACAO() throws Exception {

        new LojaServidor_Fixo(serverLoja).start();

        System.out.println(Legendar.Loja +  "SERVIDOR >> READY");

    }





}
