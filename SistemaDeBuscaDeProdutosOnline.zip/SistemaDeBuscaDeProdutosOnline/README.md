Grupo:

    Bernardo Tinti,
    Leonardo Ribeiro,
    Patrick Caetano.  